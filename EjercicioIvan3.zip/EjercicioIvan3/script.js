//Diferencia entre var y let - const

var a = 7;
var b = 12;

if (a === 7){
    let a = 4; // el alcance es dentro del bloque if
    var b = 1; // el alcance es dentro de la funcion

    console.log("Dentro del if: "+a+ "-"  +b);
} 

console.log("fuera del if:" +a+ "-" +b);

function varTest(){
    var x = 31;
    if (true) {
        var x = 71;
        console.log(x);
    }
    console.log(x);
}

function LetTest(){
    let x = 31;
    if (true) {
        let x = 71;
        console.log(x); //71
    }
    console.log(x); // 31
}


varTest();
LetTest();

const carros = ["BMW", "VOLVO", "Sabaru", "FORD", "Renault"];

let text = "";
for (let i = 0; i < carros.length; i++ ){
    text += carros [i] + "<br>";
}

document.getElementById('carros').innerHTML = text;

let numero = "";
let i = 0;

while(i < 10){
    numero += "<br>El número es: " + i;
    i++;
}

document.getElementById("numeros").innerHTML = numero;

const persona ={
    Nombre: "Ivan",
    Apellido: "Fernandez",
    Edad: 32,
    Carrera: "IPM",
};

const autos ={
    Marca:"Nissan",
    Modelo:"Sentra",
    Ano: "2017",
    Serie: 057,
    Color: "gris",
}

document.getElementById("persona").innerHTML = persona.Nombre + 
" tiene la edad de " + persona.Edad + "años. " + " Estudio " 
+ persona.Carrera;

document.getElementById("autos").innerHTML = autos ["Marca"] + 
" Modelo:" + autos["Modelo"] + "  Año:" + autos["Ano"] + "  Serie:" 
+ autos["Serie  "] + "  Color: " + autos["Color  "];

//--------------

let dia;
switch (new Date().getDay()){
    case 0:
        day = "Domingo";
        break;
    case 1:
        dia = "Lunes";
        break;
    case 2:
        dia = "Martes";
        break;
    case 3:
        day = "Miercoles";
        break;
    case 4:
        dia = "Jueves";
        break;
    case 5:
        dia = "Viernes";
        break;
    case 6:
        dia = "Sabado";
        break;         
}

document.getElementById('fecha').innerHTML = "El dia de hoy es: " + dia;